import React, { useState } from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  TextInput, 
  TouchableOpacity, 
  FlatList, 
  Image,
  SafeAreaView,
  Alert,
  ActivityIndicator
} from 'react-native';

const Card = ({ avatar_url, name, company }) => {
  return (
    <View style={styles.githubProfile}>
      <Image 
        source={{ uri: avatar_url || 'https://placehold.it/75' }} 
        style={styles.avatar} 
      />
      <View style={styles.info}>
        <Text style={styles.name}>{name}</Text>
        <Text style={styles.company}>{company || 'N/A'}</Text>
      </View>
    </View>
  );
};

const CardList = ({ profiles }) => {
  if (profiles.length === 0) {
    return (
      <View style={styles.emptyList}>
        <Text style={styles.emptyListText}>No profiles added yet</Text>
      </View>
    );
  }

  return (
    <FlatList
      data={profiles}
      renderItem={({ item }) => <Card {...item} />}
      keyExtractor={(item) => item.id.toString()}
      contentContainerStyle={styles.cardList}
    />
  );
};

const Form = ({ onSubmit }) => {
  const [userName, setUserName] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!userName.trim()) return;
    
    setLoading(true);
    try {
      const response = await fetch(`https://api.github.com/users/${userName}`);
      const data = await response.json();
      
      if (response.ok) {
        onSubmit(data);
        setUserName('');
      } else {
        Alert.alert('Error', data.message || 'User not found');
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to fetch GitHub user');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.form}>
      <TextInput
        style={styles.input}
        value={userName}
        onChangeText={setUserName}
        placeholder="GitHub username"
        placeholderTextColor="#999"
        autoCapitalize="none"
      />
      <TouchableOpacity 
        style={styles.button} 
        onPress={handleSubmit}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator color="#fff" size="small" />
        ) : (
          <Text style={styles.buttonText}>Add card</Text>
        )}
      </TouchableOpacity>
    </View>
  );
};

export default function App() {
  const [profiles, setProfiles] = useState([]);
  const title = "The GitHub Cards App";

  const addNewProfile = (profileData) => {
    // Check if the profile already exists
    if (profiles.some(profile => profile.id === profileData.id)) {
      Alert.alert('Duplicate', 'This GitHub profile is already added');
      return;
    }
    
    setProfiles([...profiles, profileData]);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>{title}</Text>
      </View>
      <Form onSubmit={addNewProfile} />
      <CardList profiles={profiles} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#24292e',
    padding: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerText: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
  },
  form: {
    padding: 15,
    flexDirection: 'row',
    marginBottom: 10,
  },
  input: {
    flex: 1,
    height: 40,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 4,
    paddingHorizontal: 10,
    backgroundColor: 'white',
    marginRight: 10,
  },
  button: {
    backgroundColor: '#28a745',
    padding: 10,
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
    minWidth: 100,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  cardList: {
    padding: 10,
  },
  githubProfile: {
    backgroundColor: 'white',
    borderRadius: 4,
    padding: 15,
    flexDirection: 'row',
    marginBottom: 10,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1,
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  info: {
    marginLeft: 15,
    justifyContent: 'center',
  },
  name: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  company: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  emptyList: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyListText: {
    fontSize: 16,
    color: '#666',
  },
});